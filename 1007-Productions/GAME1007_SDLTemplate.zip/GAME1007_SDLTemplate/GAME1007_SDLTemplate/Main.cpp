/*******************************************************************************
* File Name   :		 
* Description :	
* Author      :	
* Created     :	
* Modified    :	
*******************************************************************************/

// SDL includes pasted for convenience. Move/copy to relevant files.
#include "SDL.h"
#include "SDL_image.h"
#include "SDL_mixer.h"
#include "SDL_ttf.h"

int main(int argc, char* argv[])
{
	return 0;
}