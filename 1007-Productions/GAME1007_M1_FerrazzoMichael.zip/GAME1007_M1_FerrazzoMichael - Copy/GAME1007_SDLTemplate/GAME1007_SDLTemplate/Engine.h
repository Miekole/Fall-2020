#pragma once
#ifndef _ENGINE_H_
#define _ENGINE_H_
#include <iostream>
#include "SDL.h"
#define FPS 60
#define WIDTH 1024
#define HEIGHT 768
using namespace std;

bool g_running = false;
Uint32 g_start, g_end, g_delta, g_fps;
const Uint8* g_keystates;
SDL_Window* g_pWindow;
SDL_Renderer* g_pRenderer;

int Init(const char* title, int xPos, int yPos, int width, int height, int flags) //<--- Perameters
{
	cout << "initializing Engine....." << endl;
	if (SDL_Init(SDL_INIT_EVERYTHING) == 0) // if innitalizling is ok
	{
		// create SDL window
		g_pWindow = SDL_CreateWindow(title, xPos, yPos, width, height, flags);
		if (g_pWindow != nullptr)
		{
			// create SDL renderer... (back buffer)
			g_pRenderer = SDL_CreateRenderer(g_pWindow, -1, NULL);
			if (g_pRenderer != nullptr)
			{
				// Initalize subsystems  later...
			}
			else return false; // Renderer creation failed.
		}
		else return false; // Window creation failed. 
	}
	else return false;	// Initialization failed
	g_fps = (Uint32)round(1 / (double)FPS) * 1000; // converts FPS into milliseconds
	g_keystates = SDL_GetKeyboardState(nullptr);
	cout << "Initialization successful!" << endl;
	g_running = true;
	return true;
}

void Clean()
{
	cout << "Cleaning engine..." << endl;
	SDL_DestroyRenderer(g_pRenderer);
	SDL_DestroyWindow(g_pWindow);
	SDL_Quit();
}

void Wake()
{
	g_start = SDL_GetTicks();
}

void HandleEvents()
{
	SDL_Event event;
	while (SDL_PollEvent(&event))
	{
		switch (event.type)
		{
		case SDL_QUIT:
			g_running = false;
			break;
		}
	}
}

void Update()
{

}

void Render()
{
	SDL_SetRenderDrawColor(g_pRenderer, 255, 0, 128, 255);
	SDL_RenderClear(g_pRenderer);
	// Any drawing here... 

	SDL_RenderPresent(g_pRenderer); // Flip buffers - send data to windows.
}

void Sleep()
{
	g_end = SDL_GetTicks();
	g_delta + g_end - g_start;
	if (g_delta < g_fps)
		SDL_Delay(g_fps - g_delta);
}

int Run()
{
	if (g_running == true)
		return 1;
	// starts and runs the engine
	if (Init("GAME1007 M1", SDL_WINDOWPOS_CENTERED, SDL_WINDOWPOS_CENTERED, WIDTH, HEIGHT, NULL) == false)
		return 2;
	// we passed our irnitial checks
	while (g_running == true)
	{
		Wake();
		HandleEvents();	 // Input
		Update();		 // processing
		Render();		 // Output
		if (g_running == true)
			Sleep();
	}
	Clean();
	return 0;
	
}
#endif // !_ENGINE_H_
